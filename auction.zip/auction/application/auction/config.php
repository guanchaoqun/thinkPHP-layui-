<?php
/**
 * Created by PhpStorm.
 * User: GUO
 * Date: 2017/12/31
 * Time: 19:30
 */

return [
    // 客服联系电话
    'phone' => '13263468006',
    //项目域名
    'server_url'=>'http://carclean.cinyida.com/',
    //高尔夫公众号
    'weixin_golf'=>[
        'AppID' => 'wxe10737eaba81367f',
        'AppSecret' => '894983658f55dff436af6361db2cd05c',
    ],
];