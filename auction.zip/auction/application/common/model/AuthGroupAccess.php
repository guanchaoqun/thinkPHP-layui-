<?php
/**
 *
 * Created by PhpStorm.
 * User: 星亿达
 * Date: 2018/3/15
 * Time: 9:05
 */

namespace app\common\model;


use think\Model;

class AuthGroupAccess extends Model
{

}