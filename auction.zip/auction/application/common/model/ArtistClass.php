<?php

namespace app\common\model;


use think\Model;

class ArtistClass extends Model
{


}