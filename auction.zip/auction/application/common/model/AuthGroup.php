<?php
/**
 *
 * Created by PhpStorm.
 * User: 星亿达
 * Date: 2018/3/14
 * Time: 17:59
 */

namespace app\common\model;


use think\Model;

class AuthGroup extends Model
{

}