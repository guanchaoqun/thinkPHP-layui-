<?php


namespace app\common\model;


use think\Model;

class Member extends Model
{

}