<?php
/**
 * Created by PhpStorm.
 * User: GUO
 * Date: 2017/12/31
 * Time: 20:06
 */
return [

    'admin_title'     => '拍卖后台管理系统',
    'admin_title_abb' => '拍卖',

    'title_common' => '拍卖后台',

    // 通用控制按钮
    'create'       => '新增',
    'delete_all'   => '批量删除',
    'action'       => '操作',
    'edit'         => '编辑',
    'numbers'      => '序号',
    'sort'         => '排序',
    'create_time'  => '创建时间',
    'update_time'  => '更新时间',
    'delete_time'  => '删除时间',


];