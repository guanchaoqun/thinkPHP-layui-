<?php
/**
 * Created by PhpStorm.
 * User: GUO
 * Date: 2017/12/31
 * Time: 19:30
 */

return [
    // 登录是否验证验证码
    'login_code_check' => FALSE,
    // 是否开启多语言
    'lang_switch_on'   => TRUE,
    //是否开启权限验证
    'is_auth_check'    => FALSE,
    //充值百分比
    'recharge_percent' => 0.7,
];