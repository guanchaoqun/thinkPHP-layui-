
/**
 * 展开层
 * @param layer 弹出层对象
 * @param is_full 是否全屏
 * @param title 标题
 * @param url 地址
 * @param w 宽度
 * @param h 高德
 */
function show_layui(layer,title,url,is_full,w,h) {
    if (title == null || title == '') {
        title=false;
    };
    if (url == null || url == '') {
        url="404.html";
    };
    if (w == null || w == '') {
        w=800;
    };
    if (h == null || h == '') {
        h=(document.documentElement.clientHeight - 50);
    };
    if (is_full == null || is_full == '') {
        is_full==false;
    };

    var index=layer.open({
        type: 2,
        area: [w+'px', h +'px'],
        fix: false, //不固定
        maxmin: true,
        shade:0.4,
        title: title,
        content: url
    });

    if(is_full){
        layer.full(index);
    }
}