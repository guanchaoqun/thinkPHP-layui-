<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\phpStudy\WWW\auction\public/../application/webcontroller\view\auth_group\edit.html";i:1531368202;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="Bookmark" href="/favicon.ico" >
    <link rel="Shortcut Icon" href="/favicon.ico" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/admin/lib/html5shiv.zepto"></script>
    <script type="text/javascript" src="/static/admin/lib/respond.min.zepto"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/style.css" />
    <!--[if IE 6]>
    <script type="text/javascript" src="/static/admin/lib/DD_belatedPNG_0.0.8a-min.zepto" ></script>
    <script>DD_belatedPNG.fix('*');</script>
    <![endif]-->
    <title>角色添加</title>
    <style>
        .permission-list > dd > dl > dd{margin-left: 120px;}
        .permission-list > dd > dl > dd > label{width: 100px;}
        .permission-list > dd > dl:last-child{border-bottom: 0px;}
        input[type="radio"], input[type="checkbox"]{width: 18px;}
    </style>
</head>
<body>
<article class="page-container">
    <form action="" method="post" class="form form-horizontal" id="form-admin-role-add">
        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>角色名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" class="input-text" value="<?php echo $data['title']; ?>" placeholder="角色名称" name="title">
            </div>
        </div>

        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">是否启用：</label>
            <div class="formControls col-xs-8 col-sm-9 skin-minimal">
                <div class="radio-box">
                    <input name="status" type="radio" id="status-1" value="1" <?php if($data['status'] == '1'): ?> checked="checked" <?php endif; ?> >
                    <label for="status-1">启用</label>
                </div>
                <div class="radio-box">
                    <input type="radio" id="status-2" name="status" value="0" <?php if($data['status'] == '0'): ?> checked="checked" <?php endif; ?>>
                    <label for="status-2">禁用</label>
                </div>
            </div>
        </div>

        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">角色描述：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" class="input-text" value="<?php echo $data['notation']; ?>" placeholder="角色描述" id="" name="notation">
            </div>
        </div>

        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">角色权限：</label>
            <div class="formControls col-xs-8 col-sm-9">

                <?php if(is_array($authRuleTree) || $authRuleTree instanceof \think\Collection || $authRuleTree instanceof \think\Paginator): if( count($authRuleTree)==0 ) : echo "" ;else: foreach($authRuleTree as $k=>$v): ?>
                <dl class="permission-list">
                    <dt>
                        <label><input type="checkbox" <?php if(isset($v['ischeck']) && $v['ischeck'] == 'y'): ?>checked="checked"<?php endif; ?> value="<?php echo $v['id']; ?>" name="rules[]" id="user-Character-0"><?php echo $v['title']; ?></label>
                    </dt>
                    <dd>
                        <?php if(is_array($v['_NODE_']) || $v['_NODE_'] instanceof \think\Collection || $v['_NODE_'] instanceof \think\Paginator): if( count($v['_NODE_'])==0 ) : echo "" ;else: foreach($v['_NODE_'] as $kk=>$vv): ?>
                        <dl class="cl permission-list2">
                            <dt>
                                <label class=""><input type="checkbox" <?php if(isset($vv['ischeck']) && $vv['ischeck'] == 'y'): ?>checked="checked"<?php endif; ?> value="<?php echo $vv['id']; ?>" name="rules[]" id="user-Character-0-0"><?php echo $vv['title']; ?></label>
                            </dt>
                            <dd>
                                <?php if(is_array($vv['_NODE_']) || $vv['_NODE_'] instanceof \think\Collection || $vv['_NODE_'] instanceof \think\Paginator): if( count($vv['_NODE_'])==0 ) : echo "" ;else: foreach($vv['_NODE_'] as $kkk=>$vvv): ?>
                                <label class=""><input type="checkbox" <?php if(isset($vvv['ischeck']) && $vvv['ischeck'] == 'y'): ?>checked="checked"<?php endif; ?> value="<?php echo $vvv['id']; ?>" name="rules[]" id="user-Character-0-0-0"><?php echo $vvv['title']; ?></label>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </dd>
                        </dl>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </dd>
                </dl>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <button type="submit" class="btn btn-success radius" id="admin-role-save">
                    <i class="icon-ok"></i> 确定
                </button>
            </div>
        </div>
    </form>
</article>

<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script>
<!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/jquery.validate.js"></script>
<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/validate-methods.js"></script>
<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/messages_zh.js"></script>
<script type="text/javascript">
    $(function () {
        $('.skin-minimal input').iCheck({
            checkboxClass: 'icheckbox-blue',
            radioClass: 'iradio-yellow',
            increaseArea: '20%'
        });

        $(".permission-list dt input:checkbox").click(function () {
            $(this).closest("dl").find("dd input:checkbox").prop("checked", $(this).prop("checked"));
        });
        $(".permission-list2 input:checkbox").click(function () {
            var l = $(this).parent().parent().find("input:checked").length;
            var l2 = $(this).parents(".permission-list").find(".permission-list2 dd").find("input:checked").length;
            if ($(this).prop("checked")) {
                $(this).closest("dl").find("dt input:checkbox").prop("checked", true);
                $(this).parents(".permission-list").find("dt").first().find("input:checkbox").prop("checked", true);
            }
            else {
                // if (l == 0) {
                //     $(this).closest("dl").find("dt input:checkbox").prop("checked", false);
                // }
                // if (l2 == 0) {
                //     $(this).parents(".permission-list").find("dt").first().find("input:checkbox").prop("checked", false);
                // }
            }
        });

        $("#form-admin-role-add").validate({
            rules: {
                title: {
                    required: true,
                },
                'rules[]':{
                    required:true,
                    minlength: 3
                }
            },
            onkeyup: false,
            focusCleanup: true,
            success: "valid",
            messages:{
                'roles[]':'请选择角色权限！',
            },
            submitHandler: function (form) {
                /**
                 * 成功之后的回调函数
                 * @type {{success: options.success}}
                 */
                var options = {
                    success: function (data) {
                        if (data.code == 200) {
                            layer.msg(data.msg, {icon: 1, time: 1000});
                            setTimeout("closeWindow()", 1000);
                        } else {
                            layer.msg(data.msg, {icon: 5, time: 2000});
                        }
                    }
                };
                $(form).ajaxSubmit(options);
            }
        });
    });
    function closeWindow() {
        window.parent.location.reload();
    }
</script>
<!--/请在上方写此页面业务相关的脚本-->
</body>
</html>