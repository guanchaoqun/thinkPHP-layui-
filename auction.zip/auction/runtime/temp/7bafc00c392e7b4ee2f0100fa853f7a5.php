<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:87:"D:\phpStudy\WWW\auction\public/../application/webcontroller\view\member\createEdit.html";i:1531376494;s:64:"D:\phpStudy\WWW\auction\application\webcontroller\view\base.html";i:1531379437;s:86:"D:\phpStudy\WWW\auction\application\webcontroller\view\public\javascript_add_edit.html";i:1531383563;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title><?php echo \think\Lang::get('title_common'); ?>--<?php echo \think\Lang::get('title'); ?></title>
    <link rel="stylesheet" href="/static/webadmin/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/webadmin/bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" href="/static/lib/layui-v2.2.45/css/layui.css">
    <link rel="stylesheet" href="/static/webadmin/css/style.css">
    <script type="text/javascript" src="/static/lib/zepto/zepto.js"></script>
    <script src="/static/lib/layui-v2.2.45/layui.js"></script>
    <script src="/static/webadmin/js/js.js"></script>
    <style>
        .c-red{
            color:red;
            font-size: 18px;
            height: 38px;
            line-height: 30px;
            float: left;
        }
    </style>
</head>
<body class="lay-body layui-anim layui-anim-fadein">

<section class="content-header">
    <h1>新增/编辑</h1>
    <ol class="breadcrumb">
        <li class="active"><i class="fa fa-dashboard"></i>新增/编辑</li>
    </ol>
</section>
<div class="layui-content-box">
    <div class="panel panel-info" style="margin-bottom: 0px;">
        <div class="panel-heading">基本参数</div>
        <div class="panel-body">
            <form class="layui-form layui-form-pane" action="">
                <input type="hidden" name="id" value="<?php echo (isset($data['id']) && ($data['id'] !== '')?$data['id']:''); ?>">
                <input type="hidden" name="headimgurl" id="images" value="<?php echo (isset($data['headimgurl']) && ($data['headimgurl'] !== '')?$data['headimgurl']:''); ?>">

                <div class="layui-form-item">
                    <label class="layui-form-label"><div class="c-red">*</div>姓名</label>
                    <div class="layui-input-block">
                        <input type="text" name="nickname" value="<?php echo (isset($data['nickname']) && ($data['nickname'] !== '')?$data['nickname']:''); ?>"  lay-verify="required" placeholder="请输入姓名" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label"><div class="c-red">*</div>手机号</label>
                    <div class="layui-input-block">
                        <input type="text" name="phone" lay-verify="required" value="<?php echo (isset($data['phone']) && ($data['phone'] !== '')?$data['phone']:''); ?>"  placeholder="请输入手机号" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-upload">
                    <button type="button" class="layui-btn" id="test1">上传头像</button>
                    <div class="layui-upload-list" style="text-align:center; ">
                        <img class="layui-upload-img" id="demo1" src="<?php echo (isset($data['headimgurl']) && ($data['headimgurl'] !== '')?$data['headimgurl']:''); ?>" style="width:150px;"    >
                        <p id="demoText"></p>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">是否启用</label>
                    <div class="layui-input-block">
                        <input type="radio" name="status" value="1" title="启用" <?php if(!empty($data['status'])): if($data['status'] == '1'): ?> checked <?php endif; else: ?>checked<?php endif; ?>>
                        <input type="radio" name="status" value="9" <?php if(!empty($data['status'])): if($data['status'] == '9'): ?> checked <?php endif; endif; ?> title="禁用">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-submit">
                        <button class="layui-btn layui-btn-normal" lay-submit lay-filter="form">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>

    //一般直接写在一个js文件中
    layui.use(['form','layer','jquery','laydate'], function(){
        var $=layui.jquery,form = layui.form,layer=layui.layer,laydate = layui.laydate;
        $('.panel-body').css('min-height',$(window).height()-114+"px");
        laydate.render({
            elem: '#time1' //指定元素
            ,type:'datetime'
        });
        laydate.render({
            elem: '#time2' //指定元素
            ,type:'datetime'
        });
        // 新增和批量删除监听
        form.on('submit(form)', function(data){
            $.ajax({
                url:"<?php echo url(\think\Request::instance()->action()); ?>"
                ,data:data.field
                ,type:'POST'
                ,dataType:'json'
                ,success:function (res) {
                    switch (res.code){
                        case 200:
                            var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                            parent.layer.close(index);
                            parent.successMsg(res.msg);
                            break;
                        case 400:
                            layer.msg(res.msg,{icon:7});
                            break;
                        default:
                    }
                }
            });
            return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
        });

    });
    layui.use('upload', function() {
        var $ = layui.jquery
                , upload = layui.upload;

        //普通图片上传
        var uploadInst = upload.render({
            elem: '#test1'
            , url: '/webcontroller/common/upload/'
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#demo1').attr('src', result); //图片链接（base64）
                });
            }
            , done: function (res) {
                //如果上传失败
                if (res.code != 200) {
                    return layer.msg('上传失败');
                }
                $('.demo1').val(res.content);
                //上传成功
            }
            , error: function () {
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });
        //多图片上传
        upload.render({
            elem: '#test2'
            ,url: '/webcontroller/common/upload/'
            ,multiple: true
            ,before: function(obj){
                //预读本地文件示例，不支持ie8
                obj.preview(function(index, file, result){

                });
            }
            ,done: function(res){
                //如果上传失败
                if(res.code ==400){
                    return layer.msg(res.msg);
                }
                //上传成功
                if(res.code ==200){
                    var item = '';
                    item +="<div  class='img-conta'>";
                    item +="<img style='height: 150px;width: 150px' src='"+ res.content +"' class='layui-upload-img'>";
                    item +="<img src='/static/lib/img/close.png' class='close-img'>";
                    item += "<input class='image' type='hidden' name='image[]' value='"+res.content+"'>";
                    item +="</div>";
                    $('#demo2').append(item);
                    return layer.msg(res.msg);
                }
            }
        });
    })
    var ue = UE.getEditor('editor');
</script>

</body>
</html>