<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\phpStudy\WWW\auction\public/../application/webcontroller\view\auth_rule\index.html";i:1531368202;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="Bookmark" href="/favicon.ico" >
    <link rel="Shortcut Icon" href="/favicon.ico" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/admin/lib/html5shiv.zepto"></script>
    <script type="text/javascript" src="/static/admin/lib/respond.min.zepto"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/webadmin/bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/style.css" />
    <!--[if IE 6]>
    <script type="text/javascript" src="/static/admin/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
    <script>DD_belatedPNG.fix('*');</script>
    <![endif]-->
    <title>权限节点管理</title>
</head>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 管理员管理 <span class="c-gray en">&gt;</span> 权限管理 <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="page-container">
    <!--<div class="text-c">-->
    <!--<form class="Huiform" method="post" action="" target="_self">-->
    <!--<input type="text" class="input-text" style="width:250px" placeholder="权限名称"  name="">-->
    <!--<button type="submit" class="btn btn-success"  name=""><i class="Hui-iconfont">&#xe665;</i> 搜权限节点</button>-->
    <!--</form>-->
    <!--</div>-->
    <div class="cl pd-5 bg-1 bk-gray mb-20"> <span class="l"><a href="javascript:;" onclick="admin_permission_add('添加权限节点','<?php echo url("auth_rule/create"); ?>','','')" class="btn btn-primary radius"><i class="Hui-iconfont">&#xe600;</i> 添加权限节点</a></span> </div>
    <table class="table table-border table-bordered table-hover table-bg table-sort">
        <thead>
        <tr>
            <th scope="col" colspan="9">权限节点</th>
        </tr>
        <tr class="text-c">
            <th width="25"><input type="checkbox" name="" value=""></th>
            <th width="">节点名称</th>
            <th width="">节点地址</th>
            <th width="">节点类型</th>
            <th width="">状态</th>
            <th width="">是否菜单</th>
            <th width="">节点图标</th>
            <th width="">排序</th>
            <th width="100">操作</th>
        </tr>
        </thead>
        <tbody>
        <?php if(is_array($dataList) || $dataList instanceof \think\Collection || $dataList instanceof \think\Paginator): if( count($dataList)==0 ) : echo "" ;else: foreach($dataList as $k=>$v): ?>
            <tr class="text-c">
                <td><input type="checkbox" value="<?php echo $v['id']; ?>" name=""></td>
                <td class="text-l">
                    <?php if($v['level'] == '3'): ?>　　　│　　　├<?php endif; if($v['level'] == '2'): ?>　　　├<?php endif; ?>
                    <?php echo $v['title']; ?>
                </td>
                <td class="text-l"><?php echo $v['name']; ?></td>
                <td><?php echo $v['level_turn']; ?></td>
                <td><?php echo !empty($v['status'])?'<span class="label label-success radius">已启用</span>':'<span class="label label-danger radius">未启用</span>'; ?></td>
                <td><?php echo !empty($v['ismenu'])?'<span class="label label-success radius">是</span>':'<span class="label label-danger radius">否</span>'; ?></td>
                <td><i class="fa <?php echo $v['icon']; ?>"></i></td>
                <td><?php echo $v['sorts']; ?></td>
                <td><a title="编辑" href="javascript:;" onclick="admin_permission_edit('角色编辑','<?php echo url("auth_rule/edit",["id"=>$v['id']]); ?>','','')" class="ml-5" style="text-decoration:none"><i class="Hui-iconfont">&#xe6df;</i></a> <a title="删除" href="javascript:;" onclick="admin_permission_del(this,'<?php echo $v['id']; ?>')" class="ml-5" style="text-decoration:none"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
            </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script>
<!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="/static/admin/lib/datatables/1.10.0/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    $('.table-sort').dataTable({
        "aaSorting": [[ 0, "asc" ]],//默认第几个排序
        "bStateSave": true,//状态保存
        "aoColumnDefs": [
            //{"bVisible": false, "aTargets": [ 3 ]} //控制列的隐藏显示
            {"orderable":false,"aTargets":[1,2,6,8]}// 制定列不参与排序
        ]
    });
    /*
     参数解释：
     title	标题
     url		请求的url
     id		需要操作的数据id
     w		弹出层宽度（缺省调默认值）
     h		弹出层高度（缺省调默认值）
     */
    /*管理员-权限-添加*/
    function admin_permission_add(title,url,w,h){
        layer_show(title,url,w,h);
    }
    /*管理员-权限-编辑*/
    function admin_permission_edit(title,url,w,h){
        layer_show(title,url,w,h);
    }

    /*管理员-权限-删除*/
    function admin_permission_del(obj,id){
        layer.confirm("确定要删除吗？",{title:'提示'},function(index){
            $.ajax({
                type: 'POST',
                url: "<?php echo url('auth_rule/delete'); ?>",
                dataType: 'json',
                data:{'id':id},
                success: function(data){
                    if(data.code==200){
                        $(obj).parents("tr").remove();
                        layer.msg(data.msg,{icon:1,time:1000});
                    }else if(data.code==400){
                        layer.msg(data.msg,{icon:5,time:2000});
                    }
                }
            });
        });
    }
</script>
</body>
</html>