<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:82:"D:\phpStudy\WWW\auction\public/../application/webcontroller\view\orders\index.html";i:1531385586;s:64:"D:\phpStudy\WWW\auction\application\webcontroller\view\base.html";i:1531379437;s:83:"D:\phpStudy\WWW\auction\application\webcontroller\view\public\javascript_index.html";i:1531382290;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title><?php echo \think\Lang::get('title_common'); ?>--<?php echo \think\Lang::get('title'); ?></title>
    <link rel="stylesheet" href="/static/webadmin/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/webadmin/bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" href="/static/lib/layui-v2.2.45/css/layui.css">
    <link rel="stylesheet" href="/static/webadmin/css/style.css">
    <script type="text/javascript" src="/static/lib/zepto/zepto.js"></script>
    <script src="/static/lib/layui-v2.2.45/layui.js"></script>
    <script src="/static/webadmin/js/js.js"></script>
    <style>
        .c-red{
            color:red;
            font-size: 18px;
            height: 38px;
            line-height: 30px;
            float: left;
        }
    </style>
</head>
<body class="lay-body layui-anim layui-anim-fadein">

<section class="content-header">
    <h1>订单列表</h1>
    <ol class="breadcrumb">
        <li class="active"><i class="fa fa-dashboard"></i>订单列表</li>
    </ol>
</section>
<div class="layui-content-box">
    <div class="box">
        <div class="box-header layui-row">
            <div class="layui-col-xs12 layui-col-sm6 layui-col-md6">
                <div class="input-group">
                    <!--<button class="layui-btn layui-btn-sm layui-btn-normal monitor-action" data-action="create">-->
                        <!--<i class="layui-icon">&#xe654;</i>新增-->
                    <!--</button>-->
                    <!--<button class="layui-btn layui-btn-sm layui-btn-danger monitor-action" data-action="deleteAll">-->
                    <!--<i class="layui-icon">&#xe640;</i>批量删除-->
                    <!--</button>-->
                </div>
            </div>
            <div class="layui-input-inline layui-form">
                <div class="layui-inline">
                    <input class="layui-input" name="order_sn" id="order_sn" placeholder="输入订单编号">
                </div>
            </div>
            <div class="layui-input-inline layui-form">
                <div class="layui-inline">
                    <input class="layui-input" name="nickname" id="nickname" placeholder="输入会员名称 或手机号">
                </div>
            </div>
            <div class="layui-input-inline layui-form">
                <select name="status" id="status">
                    <!--1-待付款 2&#45;&#45;待发货 3&#45;&#45;待收货 4&#45;&#45;已完成 5&#45;&#45;违约-->
                    <option value="">请选择订单状态</option>
                    <option value="1">待付款</option>
                    <option value="2">待发货</option>
                    <option value="3">待收货</option>
                    <option value="4">已完成</option>
                    <option value="5">违约</option>
                </select>
            </div>
            <button class="layui-btn" data-type="reload">搜索</button>
        </div>
        <div class="box-body">
            <table id="lists-table" lay-filter="lists"></table>
            <script type="text/html" id="tb-status">
                <i class='fa {{# if(d.status==1){ }}fa-check-circle text-green{{# }else{ }}fa-times-circle text-red{{# } }}' lay-event="status"></i>
            </script>
            <!--操作-->
            <script type="text/html" id="tb-action">
                <a class="layui-btn  layui-btn-xs" lay-event="edit">详情</a>
            </script>
        </div>
    </div>
</div>

<script type="text/javascript">
    /**
     * 一般直接写在一个js文件中
     * 公共方法
     */
    layui.use(['table','layer','jquery'], function(){
        var $=layui.jquery,table = layui.table,layer=layui.layer;
        // 表格初始化
        table.render({
            elem: '#lists-table'
            ,url:"<?php echo url(\think\Request::instance()->controller().'/getData'); ?>"
            ,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
            ,height:'full-145'
            ,page:true
            ,limit:15
            ,limits:[15,30,50,100,200,500,1000]
            ,response: {
                statusCode: 200 //成功的状态码，默认：0
            }
            ,cols: [
                <?php echo $table; ?>
            ]
        });
        // 表格内操作监听 编辑、删除
        table.on('tool(lists)', function(obj){
            var data = obj.data;
            if(obj.event === 'detail'){
                show_layui(layer,'<?php echo \think\Lang::get('detail'); ?>',"<?php echo url('detail'); ?>"+"?id="+data.id);
            } else if(obj.event === 'del'){
                layer.confirm('真的删除吗?', function(index){
                    if(data.status==1){
//                        layer.msg('<?php echo \think\Lang::get('del_is_use'); ?>',{icon:7});return false;
                        layer.msg('启用状态数据不可删除',{icon:7});return false;
                    }
                    $.ajax({
                        url:"<?php echo url('delete'); ?>"
                        ,data:{id:data.id}
                        ,type:'POST'
                        ,dataType:'json'
                        ,success:function (res) {
                            if(res.code==200){
                                obj.del();
                                layer.close(index);
                                layer.msg(res.msg, {icon: 1,time:1000});
                            }else{
                                layer.msg(res.msg,{icon:7});
                            }
                        }
                    });
                });
            } else if(obj.event === 'edit'){
                show_layui(layer,'<?php echo \think\Lang::get('edit'); ?>',"<?php echo url('edit'); ?>"+"?id="+data.id);
            } else if(obj.event === 'status'){
                var status=data.status==1?0:1;
                $.ajax({
                    url:"<?php echo url('updatestate'); ?>"
                    ,data:{id:data.id,status:status}
                    ,type:'POST'
                    ,dataType:'json'
                    ,success:function (res) {
                        if(res.code==200){
                            //layer.msg(res.msg, {icon: 1,time:1000});
//                            successMsg(res.msg);
                            obj.update({
                                status: status
                            });
                        }else {
                            layer.msg(res.msg,{icon:7});
                        }
                    }
                });
            }
        });
//        表格数据编辑
        table.on('edit(lists)', function(obj){ //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
            var data={};
            data['id']=obj.data.id;
            data[obj.field]=obj.value;
            $.ajax({
                url:"<?php echo url('edit'); ?>"
                ,data:data
                ,type:'POST'
                ,dataType:'json'
                ,success:function (res) {
                    if(res.code==0){
                        layer.msg(res.msg, {icon: 1,time:1000});
                    }else {
                        table.reload('lists-table');
                        layer.msg(res.msg,{icon:7});
                    }
                }
            })
        });
        // 新增和批量删除监听
        $('.monitor-action').on('click',function () {
            switch ($(this).data('action')){
                case 'create':
                    show_layui(layer,'<?php echo \think\Lang::get('create'); ?>',"<?php echo url('create'); ?>");
                    break;
                case 'deleteAll':

                    break;
                default:
            }
        });

    });
    /**
     * 新增成功提示并重载数据库
     * @param layer
     * @param msg
     */
    function successMsg(msg) {
        layui.use(['table','layer'], function() {
            var table = layui.table,layer=layui.layer;
            // 成功提示
            layer.msg(msg, {icon: 1,time:2000});
            // 重载数据库
            table.reload('lists-table');
        })
    }
</script>
<script type="text/javascript">
    layui.use(['table','layer','jquery'], function(){
        var $=table = layui.table;
        //搜索
        //搜索
        var $ = layui.$, active = {
            reload: function(){
                var nickname = $('#nickname');
                var order_sn = $('#order_sn');
                var status = $('#status');
                //执行重载
                table.reload('lists-table', {
                    page: {
                        curr: 1 //重新从第 1 页开始
                    }
                    ,where: {
                        key: {
                            nickname: nickname.val(),
                            order_sn: order_sn.val(),
                            status: status.val(),
                        }
                    }
                });
            }
        };
        $('.box-header .layui-btn').on('click', function(){
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });
    });
</script>

</body>
</html>