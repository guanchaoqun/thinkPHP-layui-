<?php
/**********************************************************\
 *                                                        *
 * pay.php                                                *
 * User Vernon                                            *
 * 微信公众平台   use php5.4                               *
 * 微信支付（公众号支付）                                   *
 * LastModified: 2018-1-9                                 *
 * Author: eric <765215770@qq.com>                        *
 *                                                        *
\**********************************************************/
trait pay{
	/**
	 * 微信支付
	 * @param  string   $openId     openid
	 * @param  string   $goods      商品名称
	 * @param  string   $attach     附加参数,我们可以选择传递一个参数,比如订单ID
	 * @param  string   $order_sn   订单号
	 * @param  string   $total_fee  金额
	 */
	function wxpay($data){
	    require_once('WxPay/WxPay.JsApiPay.php');
	    $tools = new JsApiPay();
	    $input = new WxPayUnifiedOrder();
	    $input->SetBody($data['goods']);           //商品名称
	    $input->SetAttach($data['attach']);                  //附加参数,可填可不填,填写的话,里边字符串不能出现空格
	    $input->SetOut_trade_no($data['order_sn']);          //订单号
	    $input->SetTotal_fee($data['total_fee']);            //支付金额,单位:分
	    $input->SetTime_start(date("YmdHis"));       //支付发起时间
	    $input->SetTime_expire(date("YmdHis", time() + 600));//支付超时
	    $input->SetGoods_tag("test3");
	    //$input->SetNotify_url("http://".$_SERVER['HTTP_HOST']."/payment.php");
	    $input->SetNotify_url("http://carclean.cinyida.com/golf/Card/notify");//支付回调验证地址
	    $input->SetTrade_type("JSAPI");              //支付类型
	    $input->SetOpenid($data['openid']);         //用户openID
	    $order = WxPayApi::unifiedOrder($input);    //统一下单
	    $jsApiParameters = $tools->GetJsApiParameters($order);
	    return $jsApiParameters;
    }
}